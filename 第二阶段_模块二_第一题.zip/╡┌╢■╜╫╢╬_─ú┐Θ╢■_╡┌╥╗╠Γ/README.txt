

***********说明************
version:
jdk    : 11
nginx  : 1.7.9+
tomcat : 8.5+
redis  : 2.8+

数据库配置及脚本：
	数据库：test
	用户名：root 
	密码：root
访问：
	http://localhost:80/
	默认用户密码：admin/admin
***************************